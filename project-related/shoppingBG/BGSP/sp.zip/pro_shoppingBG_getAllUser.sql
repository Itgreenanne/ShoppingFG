USE ShoppingBG
GO
ALTER PROCEDURE pro_shoppingBG_getAllUser 
AS 
BEGIN

SELECT TA.f_account, TA.f_nickname, TA.f_pwd, TB.f_name
FROM t_backendUser AS TA inner join t_duty AS TB WITH(NOLOCK) ON TA.f_typeId = TB.f_id

END