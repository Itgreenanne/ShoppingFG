USE ShoppingBG
GO
ALTER PROCEDURE pro_shoppingBG_AddUser @userAccount NVARCHAR(20), @nickName NVARCHAR(20), @userPwd NVARCHAR(20), @dutyTypeId INT
AS
BEGIN

--DECLARE @result BIT 

IF NOT EXISTS (SELECT f_account FROM t_backendUser WHERE f_account = @userAccount)
BEGIN

INSERT INTO t_backendUser(f_account,f_nickname,f_pwd,f_typeId)
VALUES(@userAccount, @nickName, @userPwd, @dutyTypeId)
--SELECT result=1
SELECT 1 AS result 

END

ELSE 
BEGIN

--SELECT result=0

SELECT 0 AS result 

END

END