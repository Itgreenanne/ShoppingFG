USE ShoppingBG
GO
ALTER PROCEDURE pro_shoppingBG_getSearchUser @dutyId INT
AS 
BEGIN

SELECT t_backendUser.f_id, t_backendUser.f_account, t_backendUser.f_nickname, t_duty.f_name
FROM t_backendUser INNER JOIN t_duty WITH(NOLOCK) ON t_backendUser.f_typeId = t_duty.f_id WHERE t_backendUser.f_typeId = @dutyId

END