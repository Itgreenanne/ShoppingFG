USE ShoppingBG
GO
ALTER PROCEDURE pro_shoppingBG_ModifyDuty @dutyId INT, @dutyName NVARCHAR(20), @mangDuty bit, @mangUser bit, 
@mangProType bit, @mangProduct bit, @mangOrder bit, @mangRecord bit
AS
BEGIN

DECLARE @result BIT 

IF NOT EXISTS (SELECT f_name FROM t_duty WHERE f_name = @dutyName AND f_id!=@dutyId)
BEGIN

UPDATE t_duty
SET f_name=@dutyName, f_manageDuty=@mangDuty, f_manageUser=@mangUser, f_manageProductType=@mangProType, 
f_manageProduct=@mangProduct, f_manageOrder=@mangOrder, f_manageRecord=@mangRecord, f_updateTime=GETDATE() 
WHERE f_id=@dutyId
SELECT result=1

END

ELSE 
BEGIN

SELECT result=0

END

END